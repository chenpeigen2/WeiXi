#!/bin/sh
cd "$(dirname "$0")"
chmod +x weixi.x86_64
./weixi.x86_64
